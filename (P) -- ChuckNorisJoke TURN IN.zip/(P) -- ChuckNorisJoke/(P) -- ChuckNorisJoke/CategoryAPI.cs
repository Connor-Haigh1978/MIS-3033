﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _P_____ChuckNorisJoke
{
    public class JokeAPI
    {
        public string value { get; set; }

        public override string ToString()
        {
            return $"{value}";
        }
    }
}
